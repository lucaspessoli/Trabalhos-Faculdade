package com.mycompany.mark1;
/**
 *
 * @author Lucas Pessoli
 */
import java.util.Scanner;
public class Mark1 {

    public static void main(String[] args) {
        //Ex1 - if,else
        if (10 < 20) {
            System.out.println("Hello world!");
        } else {
            System.out.println("Hello Unipar!");
        }
        //Ex2 - Calcula Área do Triângulo4
        Scanner scn = new Scanner(System.in);
        System.out.println("Qual a sua base em cm?");
        double base = scn.nextDouble();
        System.out.println("Qual a sua altura em cm?");
        double altura = scn.nextDouble();
        double resultadoCm = (base * altura) / 2;
        double resultadoM = (base * altura / 100) / 2;
        System.out.println("O resultado em centímetros foi: " + resultadoCm);
        System.out.println("O resultado em metros foi: " + resultadoM);
        if (resultadoM > 10 && resultadoCm > 10) {
            System.out.println("Hello World!");
        } else {
            System.out.println("...");
        }
    }
    }

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package braintech.atividade;

/**
 *
 * @author aluno
 */
public class Cachorro {
    String nome;
    String corDeOlhos;
    String sobrenome;
    int idade;
    double peso;
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package braintech.atividade;

/**
 *
 * @author aluno
 */
public class Atividade {

    public static void main(String[] args) {
        Cachorro cac1 = new Cachorro();        
        cac1.nome = "dalberto";
        cac1.sobrenome = "ramos";
        cac1.corDeOlhos = "azul";
        cac1.idade = 15;
        cac1.peso = 12.2;
        Cachorro cac2 = new Cachorro();


        cac2.nome = "mario";
        cac2.sobrenome = "carlos";
        cac2.corDeOlhos = "azul";
        cac2.idade = 12;
        cac2.peso = 11.4;
        Cachorro cac3 = new Cachorro();

        
        cac3.nome = "joao";
        cac3.sobrenome = "betania";
        cac3.corDeOlhos = "castanho";
        cac3.idade = 8;
        cac3.peso = 18.2;
        Cachorro cac4 = new Cachorro();
        
        cac4.nome = "belinha";
        cac4.sobrenome = "canela";
        cac4.corDeOlhos = "preto";
        cac4.idade = 3;
        cac4.peso = 8;
        Cachorro cac5 = new Cachorro();
        
        cac5.nome = "joaquim";
        cac5.sobrenome = "pereira";
        cac5.corDeOlhos = "verde";
        cac5.idade = 6;
        cac5.peso = 28;
    }
}

package com.example.exercicio2;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Impostos extends AppCompatActivity {
    public double rendaBrutaAnual;
    public double baseCalculo;
    public double imposto;



}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.aula03032;

import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Aula03032 {

    public static void main(String[] args) {
        int n,soma=0;
        Scanner scn = new Scanner(System.in);
        
        System.out.println("Informe quantos numeros você deseja somar: ");
        n = scn.nextInt();
        int lista[]= new int[n];
        System.out.println("Informe os" + n + " numeros: ");
        
        for(int i=0;i<n;i++){
            System.out.println("Informe o " + (i+1) + " numero: ");
            lista[i]=scn.nextInt();
        }
        for(int i=0;i<n;i++){
            soma+= (lista[i]);
        }
        System.out.println("o resultado da soma dos : "+n+ " numeros é: "+ soma);
    }
}
